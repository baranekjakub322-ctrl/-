# Run Planner — dalszy rozwój

Bieżący kod to `planGenerator_v22.js` i `model/training.mjs`. Wersja V21 i niezmienione testy są w `baza_v21/`. Przeczytaj README, changelog, raporty V22 i opis pokrycia specyfikacji przed zmianami.

- Zachowuj publiczne API ESM i działające funkcje; nie buduj generatora od nowa.
- Nie osłabiaj kryteriów testowych i nie ukrywaj ostrzeżeń, odmów ani błędów procesów.
- Przed zmianami zachowaj wyniki bazowe. `npm test` wykonuje testy, pełny sweep i porównanie; `node testy/raporty_v22.mjs` odtwarza dokumentację wyników.
- Wyniki dotyczące sportowej skuteczności wymagają danych z realizacji; syntetyczna ocena ich nie zastępuje.
- Nie dodawaj strony WWW ani UI. Priorytet: bezpieczeństwo, indywidualizacja, niska częstotliwość, maraton, przejrzyste ograniczenia.
- Kontroluj deterministyczność, niemutowanie wejścia, walidację, tygodnie niepełne i granice tygodni.
- W każdej zmianie sprawdzaj rzeczywistą częstotliwość, czas, km, intensywność, regenerację i sumę tygodnia z zawodami raz.
- Aktualne wyniki zapisuj oddzielnie od historii; nie przedstawiaj nieuruchomionych testów jako zaliczonych.
