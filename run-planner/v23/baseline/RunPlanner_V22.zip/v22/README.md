# Run Planner V22

Sam generator planów biegowych JavaScript/ESM, rozwinięty bezpośrednio z dostarczonego V21. Bez strony WWW, UI i zależności zewnętrznych. Node.js ≥18; rzeczywiste uruchomienia w tej sesji: Node v24.19.0.

## Uruchomienie

```sh
cd v22
npm test                         # komplet: regresje, 9408 scenariuszy, nowe testy, porównanie
npm run test:v22                 # nowe przypadki i invariants V22
npm run compare                  # 1008 identycznych wejść V21/V22 + 14 przykładów
node testy/raporty_v22.mjs        # raporty z plików aktualnego uruchomienia
```

Nie potrzeba `npm install`. Pełny zestaw może potrwać kilka minut. Każda awaria daje niezerowy kod wyjścia; `wyniki_v22/run.json` zawiera statusy procesów, wersję Node, czas i SHA-256 źródeł. `WYNIKI=/inna/sciezka npm test` zmienia katalog wyników. Runner wymaga możliwości tworzenia procesów potomnych; EPERM sandboxa jest błędem środowiska, nie zaliczonym testem. `STOP_ON_FAIL=1`, `EXTRA_TEST=/sciezka/test.mjs` i `TESTS_ONLY_LIGHT=1` są obsługiwane. Test wymuszający awarię działa we własnym katalogu tymczasowym.

## Podstawowe API

```js
import { generatePlan } from './planGenerator_v22.js';
const result = generatePlan({
  today: '2026-11-02', age: 35, level: 'intermediate',
  availableDays: [0, 1, 2, 3, 4, 5, 6], daysPerWeek: 4,
  currentWeeklyKm: 30, longestRecentRun: 12,
  bestResult: { distanceKm: 10, timeSec: 3000, date: '2026-10-01' },
  goal: { type: 'half', raceDate: '2027-03-07', mode: 'finish' },
  recentWeeklyKm: [27, 30, 28, 30], experienceMonths: 18,
});
if (!result.ok) console.error(result.bledy);
else console.log(result.wykonalnosc, result.treningi, result.tygodnie);
```

- Daty: istniejące `YYYY-MM-DD`, obliczenia UTC. Dni: 0=niedziela … 6=sobota.
- Dystanse: `5k`, `10k`, `half`, `marathon`, `health`. Bez daty zawodów podaj całkowite `weeks` od 4 do 52. Z datą limit wynosi 730 dni.
- Poziom: `beginner`, `intermediate`, `advanced`. Objętości w km, czas treningu w minutach, wynik/cel w sekundach, tempo w sekundach/km w danych wejściowych, w formacie min:sek w wyjściowych zakresach.
- Wszystkie eksporty V21 są zachowane, m.in. `generateFromData`, `buildInput`, `replan`, `analyzeHistory`, `summarizeHistory`, `auditPlan`, `repairPlan`, `shiftPlan`, `assessGoal`, funkcje fizjologii i bezpieczeństwa. Nie ma eksportu domyślnego.
- `ok:true` oznacza poprawne wygenerowanie planu, nie kwalifikację do zawodów. Czytaj `wykonalnosc`, `gotowosc`, `ocenaCelu`, `ostrzezenia`. `trybScisly:true` odmawia celu ocenionego jako niewykonalny. Nieprawidłowe wejście lub aktywny uraz zwraca `ok:false` także bez trybu ścisłego.
- Zawody docelowe są reprezentowane w `plan.start` i `tygodnie[].start`, nie jako dodatkowy zwykły trening w `treningi`. Suma tygodnia obejmuje dystans zawodów raz. Nie dodawaj go ponownie przy agregowaniu `tygodnie[].km`.

## Nowe pola i zmiany znaczenia

| Pole | Znaczenie |
|---|---|
| `recentWeeklyKm` | Opcjonalnie 2–12 ukończonych tygodni, od najstarszego do najnowszego; 0 jest ważnym tygodniem. Baza nie przekracza deklaracji, średniej ani średniej ostatnich dwóch tygodni. Nie podawaj nieukończonego tygodnia jako pełnego. |
| `experienceMonths` | Opcjonalny staż 0–900 miesięcy. <3: bez jakości; <6: ostrożniejszy szczyt. Nie wnioskuj stażu wyłącznie z tempa. |
| `goal.mode` | `finish` usuwa presję czasu (także przesłany `targetTimeSec`); `time` lub brak pola zachowuje dotychczasowy cel czasowy. |
| `activeInjury`, `pain` | Aktywny uraz lub ból ≥4/10 blokuje generowanie. Starsze `injuries` oznacza niesprecyzowane ograniczenia: łagodna baza bez jakości. Nie jest to diagnoza. |
| `modelMaratonu` | Baza potwierdzona / odbudowa, cel ukończenia lub wynik, limit czasu długiego i ćwiczenie żywienia. |
| `indywidualizacja` | Efektywna baza, staż, historia, tryb niskiej częstotliwości i jawne wyłączenie automatycznego przyspieszania temp. |
| `korektyObciazen` | Rzeczywiste korekty kilometrów lub intensywności z wartościami przed/po i limitem. |
| `treningi[].intensywnosc` | Orientacyjne RPE i obciążenie w umownych jednostkach min×RPE; dla jakości rozgrzewka/schłodzenie mają niższą wagę. |
| `tygodnie[].obciazenieSzacunkowe` | Suma treningów; nie obejmuje nieobserwowanego RPE/czasu zawodów, co jawnie wskazuje `obciazenieUwzgledniaZawody:false`. |

Nowy wynik należy podać ponownie, aby przyspieszyć tempa; prognozowana adaptacja sama ich nie przyspiesza. Wynik starszy niż rok nie ustala intensywności, daty z przyszłości są błędem. Brak daty wyniku pozostaje kompatybilny, lecz nie potwierdza jego aktualności. Bez wiarygodnego wyniku RPE/test rozmowy ma pierwszeństwo; zachowano orientacyjne numeryczne zakresy dla kompatybilności klientów. `trzymajCel` nie omija ograniczenia intensywności dla nierealnego celu.

## Model treningowy i bezpieczeństwo

Jeden bieg: podtrzymanie/wejście, bez upychania akcentów; niepełne przygotowanie startowe. Dwa biegi: rotacja łatwy/dłuższy i okazjonalny akcent; na 5 km mogą wystąpić krótkie interwały, na 10 km tempo, na HM rzadsze tempo, na maraton wyłącznie alternatywa budowania bazy. Priorytetem są przerwy i tolerancja obciążenia, nie wymagane minimum jakości.

Maraton ma osobny podział baza → budowanie → specyfika → taper. Przy odpowiedniej bazie co najmniej czterech biegów wchodzą odcinki MP także dla celu ukończenia; trening progowy nie jest dokładany na końcu długiego biegu. Długi bieg mieści się w realnej objętości, czasie dnia i ostrożnym limicie 180 min dla początkujących lub 195 min dla pozostałych. Niska baza nie jest kompensowana skokiem km. Wskazówki żywienia są ćwiczeniem tolerancji, nie indywidualną dietą.

Rampa zależy od poziomu, wieku, historii przeciążeń/przerwy i stażu; istnieją odciążenia i taper specyficzny dla dystansu/dnia zawodów. Dodatkowy strażnik sprawdza realne, zaokrąglone km: maksimum `max(1.12 × poprzednie obciążenie km, poprzednie +3 km)` w zwykłym pełnym tygodniu. To sufit, nie obowiązkowy przyrost. Osobny strażnik min×RPE nie pozwala wprowadzić akcentu powyżej `max(1.25 × poprzednie, poprzednie +60)`; w razie konfliktu zamienia go na łatwy bieg i rejestruje decyzję. Reguły nie są uniwersalnym prawem fizjologii ani celem, który trzeba osiągnąć.

## Pliki i audyt wyników

- `planGenerator_v22.js`, `model/training.mjs`: produkcyjny generator i reguły V22.
- `planGenerator_v21.js`, `baza_v21/`: niezmieniona baza i oryginalne testy/raporty; `wyniki_bazowe_v21/` to ponownie wykonana baza w tej sesji.
- `testy/`: zachowane testy z techniczną migracją wskazania generatora i asercji wersji; nowe reguły niezależne w `miernik_v22.mjs`, przypadki V22 i porównanie.
- `wyniki/` oraz raporty V20/V21 są historyczne; aktualne wyniki są wyłącznie w `wyniki_v22/`. Dwa stare porównania testują historyczne wersje V19/V20/V21, co jest jawnie oddzielone w raporcie.
- `przyklady/*.json`: pełne wejścia i wygenerowane plany 14 profili. `przyklady/omowienie.md` zawiera kontrolę i wybrane tygodnie.
- `raport_testow_v22.md`, `porownanie_v21_v22.md`, `ocena_jakosci_v22.md`, `zmiany_v21_v22.md`, `pokrycie_specyfikacji.md` opisują wyniki i zakres.

## Ograniczenia i V23

To heurystyki, nie dowód skuteczności sportowej ani zastępstwo diagnostyki/trenera. Wynik 10/10 miernika nie oznacza idealnego planu. Brakuje badań na biegaczach, potwierdzonej tolerancji obciążeń, szczegółowej historii klinicznej, snu/energii/terenu i indywidualnej tolerancji żywienia. RPE obciążeń to oszacowanie, nie zarejestrowany wysiłek. Niepełne tygodnie, marszobiegi, tygodnie zawodów i starty dodatkowe wymagają osobnego przeglądu; nowy strażnik intensywności nie zastępuje ich istniejących zabezpieczeń. Obsługa bardzo małej częstotliwości świadomie ogranicza przygotowanie. Maksymalnie 6 realnych biegów dla dostatecznie przygotowanego zawodnika; deklaracja 7 jest jawnie ograniczana.

Progi gotowości są zachowawcze: obniżenie jakości/objętości może zmniejszać ocenę gotowości i nie jest naprawiane zmianą scoringu. Zalecane V23: prospektywna walidacja realizacji i urazów, kalibracja tolerancji indywidualnej, lepszy model zmęczenia z obserwowanego RPE, oddzielenie pozostałych modułów dużego pliku i testy całego API historii na danych długoterminowych.
