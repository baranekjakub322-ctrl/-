# Start — Run Planner V22

1. Przeczytaj `README.md` (API, wymagania Node i ograniczenia).
2. Bieżący generator to `planGenerator_v22.js` + `model/training.mjs`.
3. Uruchom `npm test`, aby odtworzyć komplet kontroli; nie trzeba instalować zależności.
4. Wyniki dostarczonej wersji: `raport_testow_v22.md`, `porownanie_v21_v22.md`, `ocena_jakosci_v22.md` i `wyniki_v22/`.
5. Pełne przykłady: `przyklady/`; omówienie: `przyklady/omowienie.md`.
6. Oryginalna baza: `baza_v21/`, ponownie wykonane testy bazy: `wyniki_bazowe_v21/`.

`PROMPT_V22_DLA_CODEX.md` i `HISTORIA_I_KONTEKST.md` zachowują kontekst wymagań i historii; wskazane w nich pierwotne ścieżki `projekt/v21` odpowiadają teraz zachowanej bazie `baza_v21`. Raporty historyczne nie zastępują aktualnych wyników.
